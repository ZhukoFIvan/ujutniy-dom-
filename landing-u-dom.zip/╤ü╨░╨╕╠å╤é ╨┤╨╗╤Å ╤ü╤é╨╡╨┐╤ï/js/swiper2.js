new Swiper('.swiper', {
	pagination: {
		el: '.swiper-pagination',
		clickable: true,

	},
	
	slidesPerView: 2,
	spaceBetween: 0,
	loop: true,
	// autoplay: {
	// 	delay: 3000,
	// 	stopOnLastSlide: false,
	// 	disableOnInteraction: false
	// },
	breakpoints: {
		
		640: {
			slidesPerView: 3,
			spaceBetween: 10,
		}}

})







