$('.slider_brandss').slick({
	arrows: false,
	dots: false,
	slidesToShow: 5,
	speed: 1000,
	infinite: true,
	autoplay: true,
	pauseOnFocus: false,
	responsive: [
		{
			breakpoint: 1200,
			settings: {
				slidesToShow: 4,


			}
		},
		{
			breakpoint: 700,
			settings: {
				slidesToShow: 3,
				slidesToScroll: 3
			}
		},
		{
			breakpoint: 500,
			settings: {
				slidesToShow: 2,
				slidesToScroll: 2
			}
		},
		{
			breakpoint: 350,
			settings: {
				slidesToShow: 1,
				slidesToScroll: 1
			}
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	]



})