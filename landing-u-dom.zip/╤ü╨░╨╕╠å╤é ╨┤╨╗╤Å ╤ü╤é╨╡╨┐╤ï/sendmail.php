<?php

		$name = $_POST['name'];
		$phone = $_POST['phone'];


		$name = htmlspecialchars($name);
		$name = htmlspecialchars($phone);

		$name = urldecode($name);
		$name = urldecode($phone);

		$name = trim($name);
		$name = trim($phone);

		if (mail("jukov0411200303@gmail.com",
						"Новое письмо с сайта",
						"Имя: ".$name."\n".
						"Телефон: ".$phone."\n".)
		){
			echo('письмо успешно отправлено');
		}

		else{
			echo('Есть ошибки');
		}

?>